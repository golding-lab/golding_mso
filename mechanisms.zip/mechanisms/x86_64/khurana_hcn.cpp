/* Created by Language version: 7.7.0 */
/* VECTORIZED */
#define NRN_VECTORIZED 1
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mech_api.h"
#undef PI
#define nil 0
#define _pval pval
// clang-format off
#include "md1redef.h"
#include "section_fwd.hpp"
#include "nrniv_mf.h"
#include "md2redef.h"
#include "nrnconf.h"
// clang-format on
#include "neuron/cache/mechanism_range.hpp"
static constexpr auto number_of_datum_variables = 3;
static constexpr auto number_of_floating_point_variables = 10;
namespace {
template <typename T>
using _nrn_mechanism_std_vector = std::vector<T>;
using _nrn_model_sorted_token = neuron::model_sorted_token;
using _nrn_mechanism_cache_range = neuron::cache::MechanismRange<number_of_floating_point_variables, number_of_datum_variables>;
using _nrn_mechanism_cache_instance = neuron::cache::MechanismInstance<number_of_floating_point_variables, number_of_datum_variables>;
using _nrn_non_owning_id_without_container = neuron::container::non_owning_identifier_without_container;
template <typename T>
using _nrn_mechanism_field = neuron::mechanism::field<T>;
template <typename... Args>
void _nrn_mechanism_register_data_fields(Args&&... args) {
  neuron::mechanism::register_data_fields(std::forward<Args>(args)...);
}
}
 
#if !NRNGPU
#undef exp
#define exp hoc_Exp
#if NRN_ENABLE_ARCH_INDEP_EXP_POW
#undef pow
#define pow hoc_pow
#endif
#endif
 
#define nrn_init _nrn_init__khurana_hcn
#define _nrn_initial _nrn_initial__khurana_hcn
#define nrn_cur _nrn_cur__khurana_hcn
#define _nrn_current _nrn_current__khurana_hcn
#define nrn_jacob _nrn_jacob__khurana_hcn
#define nrn_state _nrn_state__khurana_hcn
#define _net_receive _net_receive__khurana_hcn 
#define states states__khurana_hcn 
 
#define _threadargscomma_ _ml, _iml, _ppvar, _thread, _globals, _nt,
#define _threadargsprotocomma_ Memb_list* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt,
#define _internalthreadargsprotocomma_ _nrn_mechanism_cache_range* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt,
#define _threadargs_ _ml, _iml, _ppvar, _thread, _globals, _nt
#define _threadargsproto_ Memb_list* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt
#define _internalthreadargsproto_ _nrn_mechanism_cache_range* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *hoc_getarg(int);
 
#define t _nt->_t
#define dt _nt->_dt
#define gbar _ml->template fpfield<0>(_iml)
#define gbar_columnindex 0
#define gh _ml->template fpfield<1>(_iml)
#define gh_columnindex 1
#define ih _ml->template fpfield<2>(_iml)
#define ih_columnindex 2
#define rf _ml->template fpfield<3>(_iml)
#define rf_columnindex 3
#define rs _ml->template fpfield<4>(_iml)
#define rs_columnindex 4
#define eh _ml->template fpfield<5>(_iml)
#define eh_columnindex 5
#define Drf _ml->template fpfield<6>(_iml)
#define Drf_columnindex 6
#define Drs _ml->template fpfield<7>(_iml)
#define Drs_columnindex 7
#define v _ml->template fpfield<8>(_iml)
#define v_columnindex 8
#define _g _ml->template fpfield<9>(_iml)
#define _g_columnindex 9
#define _ion_eh *(_ml->dptr_field<0>(_iml))
#define _p_ion_eh static_cast<neuron::container::data_handle<double>>(_ppvar[0])
#define _ion_ih *(_ml->dptr_field<1>(_iml))
#define _p_ion_ih static_cast<neuron::container::data_handle<double>>(_ppvar[1])
#define _ion_dihdv *(_ml->dptr_field<2>(_iml))
 /* Thread safe. No static _ml, _iml or _ppvar. */
 static int hoc_nrnpointerindex =  -1;
 static _nrn_mechanism_std_vector<Datum> _extcall_thread;
 static Prop* _extcall_prop;
 /* _prop_id kind of shadows _extcall_prop to allow validity checking. */
 static _nrn_non_owning_id_without_container _prop_id{};
 /* external NEURON variables */
 /* declaration of user functions */
 static void _hoc_r_inf(void);
 static void _hoc_tau_s(void);
 static void _hoc_tau_f(void);
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
 
#define NMODL_TEXT 1
#if NMODL_TEXT
static void register_nmodl_text_and_filename(int mechtype);
#endif
 static void _hoc_setdata();
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 {"setdata_khurana_hcn", _hoc_setdata},
 {"r_inf_khurana_hcn", _hoc_r_inf},
 {"tau_s_khurana_hcn", _hoc_tau_s},
 {"tau_f_khurana_hcn", _hoc_tau_f},
 {0, 0}
};
 
/* Direct Python call wrappers to density mechanism functions.*/
 static double _npy_r_inf(Prop*);
 static double _npy_tau_s(Prop*);
 static double _npy_tau_f(Prop*);
 
static NPyDirectMechFunc npy_direct_func_proc[] = {
 {"r_inf", _npy_r_inf},
 {"tau_s", _npy_tau_s},
 {"tau_f", _npy_tau_f},
 {0, 0}
};
#define r_inf r_inf_khurana_hcn
#define tau_s tau_s_khurana_hcn
#define tau_f tau_f_khurana_hcn
 extern double r_inf( _internalthreadargsprotocomma_ double );
 extern double tau_s( _internalthreadargsprotocomma_ double );
 extern double tau_f( _internalthreadargsprotocomma_ double );
 /* declare global and static user variables */
 #define gind 0
 #define _gth 0
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 {0, 0, 0}
};
 static HocParmUnits _hoc_parm_units[] = {
 {"gbar_khurana_hcn", "mho/cm2"},
 {"gh_khurana_hcn", "mho/cm2"},
 {"ih_khurana_hcn", "mA/cm2"},
 {0, 0}
};
 static double delta_t = 0.01;
 static double rs0 = 0;
 static double rf0 = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 {0, 0}
};
 static DoubVec hoc_vdoub[] = {
 {0, 0, 0}
};
 static double _sav_indep;
 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _extcall_prop = _prop;
 _prop_id = _nrn_get_prop_id(_prop);
 }
 static void _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range(int);
 _prop = hoc_getdata_range(_mechtype);
   _setdata(_prop);
 hoc_retpushx(1.);
}
 static void nrn_alloc(Prop*);
static void nrn_init(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void nrn_state(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 static void nrn_cur(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void nrn_jacob(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 
static int _ode_count(int);
static void _ode_map(Prop*, int, neuron::container::data_handle<double>*, neuron::container::data_handle<double>*, double*, int);
static void _ode_spec(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void _ode_matsol(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 
#define _cvode_ieq _ppvar[3].literal_value<int>()
 static void _ode_matsol_instance1(_internalthreadargsproto_);
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "7.7.0",
"khurana_hcn",
 "gbar_khurana_hcn",
 0,
 "gh_khurana_hcn",
 "ih_khurana_hcn",
 0,
 "rf_khurana_hcn",
 "rs_khurana_hcn",
 0,
 0};
 static Symbol* _h_sym;
 
 /* Used by NrnProperty */
 static _nrn_mechanism_std_vector<double> _parm_default{
     0.005, /* gbar */
 }; 
 
 
extern Prop* need_memb(Symbol*);
static void nrn_alloc(Prop* _prop) {
  Prop *prop_ion{};
  Datum *_ppvar{};
   _ppvar = nrn_prop_datum_alloc(_mechtype, 4, _prop);
    _nrn_mechanism_access_dparam(_prop) = _ppvar;
     _nrn_mechanism_cache_instance _ml_real{_prop};
    auto* const _ml = &_ml_real;
    size_t const _iml{};
    assert(_nrn_mechanism_get_num_vars(_prop) == 10);
 	/*initialize range parameters*/
 	gbar = _parm_default[0]; /* 0.005 */
 	 assert(_nrn_mechanism_get_num_vars(_prop) == 10);
 	_nrn_mechanism_access_dparam(_prop) = _ppvar;
 	/*connect ionic variables to this model*/
 prop_ion = need_memb(_h_sym);
 nrn_promote(prop_ion, 0, 1);
 	_ppvar[0] = _nrn_mechanism_get_param_handle(prop_ion, 0); /* eh */
 	_ppvar[1] = _nrn_mechanism_get_param_handle(prop_ion, 3); /* ih */
 	_ppvar[2] = _nrn_mechanism_get_param_handle(prop_ion, 4); /* _ion_dihdv */
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 {0, 0}
};
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*)(Datum*));
void _nrn_thread_table_reg(int, nrn_thread_table_check_t);
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 extern "C" void _khurana_hcn_reg() {
	int _vectorized = 1;
  _initlists();
 	ion_reg("h", 1.0);
 	_h_sym = hoc_lookup("h_ion");
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 1);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
 hoc_register_parm_default(_mechtype, &_parm_default);
         hoc_register_npy_direct(_mechtype, npy_direct_func_proc);
     _nrn_setdata_reg(_mechtype, _setdata);
 #if NMODL_TEXT
  register_nmodl_text_and_filename(_mechtype);
#endif
   _nrn_mechanism_register_data_fields(_mechtype,
                                       _nrn_mechanism_field<double>{"gbar"} /* 0 */,
                                       _nrn_mechanism_field<double>{"gh"} /* 1 */,
                                       _nrn_mechanism_field<double>{"ih"} /* 2 */,
                                       _nrn_mechanism_field<double>{"rf"} /* 3 */,
                                       _nrn_mechanism_field<double>{"rs"} /* 4 */,
                                       _nrn_mechanism_field<double>{"eh"} /* 5 */,
                                       _nrn_mechanism_field<double>{"Drf"} /* 6 */,
                                       _nrn_mechanism_field<double>{"Drs"} /* 7 */,
                                       _nrn_mechanism_field<double>{"v"} /* 8 */,
                                       _nrn_mechanism_field<double>{"_g"} /* 9 */,
                                       _nrn_mechanism_field<double*>{"_ion_eh", "h_ion"} /* 0 */,
                                       _nrn_mechanism_field<double*>{"_ion_ih", "h_ion"} /* 1 */,
                                       _nrn_mechanism_field<double*>{"_ion_dihdv", "h_ion"} /* 2 */,
                                       _nrn_mechanism_field<int>{"_cvode_ieq", "cvodeieq"} /* 3 */);
  hoc_register_prop_size(_mechtype, 10, 4);
  hoc_register_dparam_semantics(_mechtype, 0, "h_ion");
  hoc_register_dparam_semantics(_mechtype, 1, "h_ion");
  hoc_register_dparam_semantics(_mechtype, 2, "h_ion");
  hoc_register_dparam_semantics(_mechtype, 3, "cvodeieq");
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 
    hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 khurana_hcn /Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/khurana_hcn.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
static int _reset;
static const char *modelname = "";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
 
static int _ode_spec1(_internalthreadargsproto_);
/*static int _ode_matsol1(_internalthreadargsproto_);*/
 static neuron::container::field_index _slist1[2], _dlist1[2];
 static int states(_internalthreadargsproto_);
 
/*CVODE*/
 static int _ode_spec1 (_internalthreadargsproto_) {int _reset = 0; {
   Drf = ( r_inf ( _threadargscomma_ v ) - rf ) / tau_f ( _threadargscomma_ v ) ;
   Drs = ( r_inf ( _threadargscomma_ v ) - rs ) / tau_s ( _threadargscomma_ v ) ;
   }
 return _reset;
}
 static int _ode_matsol1 (_internalthreadargsproto_) {
 Drf = Drf  / (1. - dt*( ( ( ( - 1.0 ) ) ) / tau_f ( _threadargscomma_ v ) )) ;
 Drs = Drs  / (1. - dt*( ( ( ( - 1.0 ) ) ) / tau_s ( _threadargscomma_ v ) )) ;
  return 0;
}
 /*END CVODE*/
 static int states (_internalthreadargsproto_) { {
    rf = rf + (1. - exp(dt*(( ( ( - 1.0 ) ) ) / tau_f ( _threadargscomma_ v ))))*(- ( ( ( r_inf ( _threadargscomma_ v ) ) ) / tau_f ( _threadargscomma_ v ) ) / ( ( ( ( - 1.0 ) ) ) / tau_f ( _threadargscomma_ v ) ) - rf) ;
    rs = rs + (1. - exp(dt*(( ( ( - 1.0 ) ) ) / tau_s ( _threadargscomma_ v ))))*(- ( ( ( r_inf ( _threadargscomma_ v ) ) ) / tau_s ( _threadargscomma_ v ) ) / ( ( ( ( - 1.0 ) ) ) / tau_s ( _threadargscomma_ v ) ) - rs) ;
   }
  return 0;
}
 
double r_inf ( _internalthreadargsprotocomma_ double _lVm ) {
   double _lr_inf;
  _lr_inf = 1.0 / ( 1.0 + exp ( ( _lVm + 60.3 ) / ( 7.3 ) ) ) ;
    
return _lr_inf;
 }
 
static void _hoc_r_inf(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
_nt = nrn_threads;
 _r =  r_inf ( _threadargscomma_ *getarg(1) );
 hoc_retpushx(_r);
}
 
static double _npy_r_inf(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
_nt = nrn_threads;
 _r =  r_inf ( _threadargscomma_ *getarg(1) );
 return(_r);
}
 
double tau_f ( _internalthreadargsprotocomma_ double _lVm ) {
   double _ltau_f;
  _ltau_f = 10000.0 / ( ( - 7.4 * ( _lVm + 60.0 ) / ( exp ( - ( _lVm + 60.0 ) / 0.8 ) - 1.0 ) ) + 65.0 * exp ( - ( _lVm + 56.0 ) / 23.0 ) ) ;
    
return _ltau_f;
 }
 
static void _hoc_tau_f(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
_nt = nrn_threads;
 _r =  tau_f ( _threadargscomma_ *getarg(1) );
 hoc_retpushx(_r);
}
 
static double _npy_tau_f(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
_nt = nrn_threads;
 _r =  tau_f ( _threadargscomma_ *getarg(1) );
 return(_r);
}
 
double tau_s ( _internalthreadargsprotocomma_ double _lVm ) {
   double _ltau_s;
  _ltau_s = 1000000.0 / ( ( - 56.0 * ( _lVm + 59.0 ) / ( exp ( - ( _lVm + 59.0 ) / 0.8 ) - 1.0 ) ) + 0.24 * exp ( - ( _lVm - 68.0 ) / 16.0 ) ) ;
    
return _ltau_s;
 }
 
static void _hoc_tau_s(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
_nt = nrn_threads;
 _r =  tau_s ( _threadargscomma_ *getarg(1) );
 hoc_retpushx(_r);
}
 
static double _npy_tau_s(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
_nt = nrn_threads;
 _r =  tau_s ( _threadargscomma_ *getarg(1) );
 return(_r);
}
 
static int _ode_count(int _type){ return 2;}
 
static void _ode_spec(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
   Datum* _ppvar;
   size_t _iml;   _nrn_mechanism_cache_range* _ml;   Node* _nd{};
  double _v{};
  int _cntml;
  _nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
  _ml = &_lmr;
  _cntml = _ml_arg->_nodecount;
  Datum *_thread{_ml_arg->_thread};
  double* _globals = nullptr;
  if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _ppvar = _ml_arg->_pdata[_iml];
    _nd = _ml_arg->_nodelist[_iml];
    v = NODEV(_nd);
  eh = _ion_eh;
     _ode_spec1 (_threadargs_);
  }}
 
static void _ode_map(Prop* _prop, int _ieq, neuron::container::data_handle<double>* _pv, neuron::container::data_handle<double>* _pvdot, double* _atol, int _type) { 
  Datum* _ppvar;
  _ppvar = _nrn_mechanism_access_dparam(_prop);
  _cvode_ieq = _ieq;
  for (int _i=0; _i < 2; ++_i) {
    _pv[_i] = _nrn_mechanism_get_param_handle(_prop, _slist1[_i]);
    _pvdot[_i] = _nrn_mechanism_get_param_handle(_prop, _dlist1[_i]);
    _cvode_abstol(_atollist, _atol, _i);
  }
 }
 
static void _ode_matsol_instance1(_internalthreadargsproto_) {
 _ode_matsol1 (_threadargs_);
 }
 
static void _ode_matsol(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
   Datum* _ppvar;
   size_t _iml;   _nrn_mechanism_cache_range* _ml;   Node* _nd{};
  double _v{};
  int _cntml;
  _nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
  _ml = &_lmr;
  _cntml = _ml_arg->_nodecount;
  Datum *_thread{_ml_arg->_thread};
  double* _globals = nullptr;
  if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _ppvar = _ml_arg->_pdata[_iml];
    _nd = _ml_arg->_nodelist[_iml];
    v = NODEV(_nd);
  eh = _ion_eh;
 _ode_matsol_instance1(_threadargs_);
 }}

static void initmodel(_internalthreadargsproto_) {
  int _i; double _save;{
  rs = rs0;
  rf = rf0;
 {
   rf = r_inf ( _threadargscomma_ v ) ;
   rs = r_inf ( _threadargscomma_ v ) ;
   }
 
}
}

static void nrn_init(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type){
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto* const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (_iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
   _v = _vec_v[_ni[_iml]];
 v = _v;
  eh = _ion_eh;
 initmodel(_threadargs_);
 }
}

static double _nrn_current(_internalthreadargsprotocomma_ double _v) {
double _current=0.; v=_v;
{ {
   gh = gbar * ( 0.65 * rf + ( 1.0 - 0.65 ) * rs ) ;
   ih = gh * ( v - eh ) ;
   }
 _current += ih;

} return _current;
}

static void nrn_cur(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto const _vec_rhs = _nt->node_rhs_storage();
auto const _vec_sav_rhs = _nt->node_sav_rhs_storage();
auto const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (_iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
   _v = _vec_v[_ni[_iml]];
  eh = _ion_eh;
 auto const _g_local = _nrn_current(_threadargscomma_ _v + .001);
 	{ double _dih;
  _dih = ih;
 _rhs = _nrn_current(_threadargscomma_ _v);
  _ion_dihdv += (_dih - ih)/.001 ;
 	}
 _g = (_g_local - _rhs)/.001;
  _ion_ih += ih ;
	 _vec_rhs[_ni[_iml]] -= _rhs;
 
}
 
}

static void nrn_jacob(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto const _vec_d = _nt->node_d_storage();
auto const _vec_sav_d = _nt->node_sav_d_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (_iml = 0; _iml < _cntml; ++_iml) {
  _vec_d[_ni[_iml]] += _g;
 
}
 
}

static void nrn_state(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto* const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; double _v = 0.0; int* _ni;
_ni = _ml_arg->_nodeindices;
size_t _cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (size_t _iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
 _nd = _ml_arg->_nodelist[_iml];
   _v = _vec_v[_ni[_iml]];
 v=_v;
{
  eh = _ion_eh;
 {   states(_threadargs_);
  } }}

}

static void terminal(){}

static void _initlists(){
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = {rf_columnindex, 0};  _dlist1[0] = {Drf_columnindex, 0};
 _slist1[1] = {rs_columnindex, 0};  _dlist1[1] = {Drs_columnindex, 0};
_first = 0;
}

#if NMODL_TEXT
static void register_nmodl_text_and_filename(int mech_type) {
    const char* nmodl_filename = "/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/khurana_hcn.mod";
    const char* nmodl_file_text = 
  "\n"
  "\n"
  "NEURON {\n"
  "SUFFIX khurana_hcn	USEION h  READ eh  WRITE ih VALENCE 1  RANGE gbar, ih,gh }\n"
  "\n"
  "\n"
  "\n"
  "\n"
  "\n"
  "UNITS {\n"
  "	(mA) = (milliamp)\n"
  "	(mV) = (millivolt)\n"
  "}\n"
  "\n"
  "\n"
  "\n"
  "PARAMETER {\n"
  "gbar= 0.005	(mho/cm2) eh= -39 (mV)\n"
  "\n"
  "} \n"
  "\n"
  "\n"
  "ASSIGNED {\n"
  "gh(mho/cm2)\n"
  "	ih(mA/cm2)\n"
  " v (mV)\n"
  "}\n"
  "    \n"
  "\n"
  "\n"
  "STATE {\n"
  "	rf rs }\n"
  "\n"
  "\n"
  "\n"
  "\n"
  "BREAKPOINT {\n"
  "SOLVE states\n"
  " METHOD cnexp \n"
  "gh=gbar*(0.65*rf +(1-0.65)*rs) \n"
  "ih=gh*(v-eh)\n"
  "}\n"
  "\n"
  "\n"
  "\n"
  "\n"
  "\n"
  "\n"
  "INITIAL {\n"
  "	rf= r_inf(v)\n"
  "	rs = r_inf(v)\n"
  "\n"
  "}\n"
  "\n"
  "\n"
  "DERIVATIVE states{\n"
  "	rf'= (r_inf(v) - rf)/tau_f(v)\n"
  "	rs'= (r_inf(v) - rs)/tau_s(v)   }\n"
  "\n"
  "FUNCTION r_inf(Vm (mV)) () {\n"
  "	UNITSOFF \n"
  "	r_inf = 1/(1+exp((Vm+60.3)/(7.3)))\n"
  "	UNITSON\n"
  "}\n"
  "\n"
  "\n"
  "FUNCTION tau_f(Vm (mV)) (ms) {\n"
  "	UNITSOFF \n"
  "	tau_f= 10000/( (-7.4*(Vm + 60)/(exp(-(Vm+60)/0.8)-1 ))   +   65*exp(-(Vm+56)/23))\n"
  "	UNITSON\n"
  "}\n"
  "\n"
  "FUNCTION tau_s(Vm (mV)) (ms) {\n"
  "	UNITSOFF \n"
  "	tau_s= 1000000/( (-56*(Vm + 59)/(exp(-(Vm+59)/0.8)-1 ))   +   0.24*exp(-(Vm-68)/16))\n"
  "	UNITSON\n"
  "}\n"
  "\n"
  "\n"
  "\n"
  "\n"
  "\n"
  ;
    hoc_reg_nmodl_filename(mech_type, nmodl_filename);
    hoc_reg_nmodl_text(mech_type, nmodl_file_text);
}
#endif
