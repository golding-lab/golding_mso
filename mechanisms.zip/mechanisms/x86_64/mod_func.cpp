#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern "C" void _baumann_dorsal_hcn_reg(void);
extern "C" void _baumann_ventral_hcn_reg(void);
extern "C" void _khurana_hcn_reg(void);
extern "C" void _leak_reg(void);
extern "C" void _leak_hcn_reg(void);
extern "C" void _leak_kht_reg(void);
extern "C" void _leak_klt_reg(void);
extern "C" void _mathews_klt_reg(void);
extern "C" void _nabel_kht_reg(void);
extern "C" void _scott_na_reg(void);
extern "C" void _spencer_na_reg(void);
extern "C" void _vecevent_reg(void);

extern "C" void modl_reg() {
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/baumann_dorsal_hcn.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/baumann_ventral_hcn.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/khurana_hcn.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/leak.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/leak_hcn.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/leak_kht.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/leak_klt.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/mathews_klt.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/nabel_kht.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/scott_na.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/spencer_na.mod\"");
    fprintf(stderr, " \"/Volumes/oj_hardrive/golding-lab/golding_mso_project/golding_mso/golding_mso/mechanisms/vecevent.mod\"");
    fprintf(stderr, "\n");
  }
  _baumann_dorsal_hcn_reg();
  _baumann_ventral_hcn_reg();
  _khurana_hcn_reg();
  _leak_reg();
  _leak_hcn_reg();
  _leak_kht_reg();
  _leak_klt_reg();
  _mathews_klt_reg();
  _nabel_kht_reg();
  _scott_na_reg();
  _spencer_na_reg();
  _vecevent_reg();
}
