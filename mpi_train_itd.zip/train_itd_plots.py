"""Plotting for train_allcell: live ITD curves / traces per cell and the final
averaged-trace figure. Reads from a train_data.ResultsCollector; never writes results."""

import numpy as np


class Plotter:
    def __init__(self, cells, freqs, orders, stim, plot_window, plot_folder, traces=False, only_aps=False):
        import matplotlib as mpl
        import matplotlib.pyplot as plt

        self.plt = plt
        self.cells = list(cells)
        self.freqs = freqs
        self.orders = orders if len(orders) > 0 else [99]
        self.stim = stim
        self.plot_window = plot_window
        self.plot_folder = plot_folder
        self.traces = traces
        self.only_aps = only_aps

        plt.ion()
        if self.freqs:
            self.freq_cmap = mpl.colormaps["plasma"]
            self.freq_norm = mpl.colors.LogNorm(vmin=min(freqs), vmax=max(freqs))
        self.master_figs, self.master_axes = {}, {}
        self.trace_figs, self.trace_axes = {}, {}
        for name in self.cells:
            mfig, max_ = plt.subplots(1, 1, figsize=(6, 4))
            mfig.tight_layout()
            self.master_figs[name] = mfig
            self.master_axes[name] = max_
            if traces:
                for order in self.orders:
                    tfig, tax_ = plt.subplots(
                        len(freqs) if self.freqs else 1, 1,
                        figsize=(24, (len(freqs) if self.freqs else 1) * 2),
                        squeeze=False, sharex=True, sharey=True,
                    )
                    tfig.tight_layout()
                    self.trace_figs[f"{name}_{order}"] = tfig
                    self.trace_axes[f"{name}_{order}"] = tax_
            if not traces:
                continue

    # ── live updates ──
    def update(self, cell_name, order, results, sweeps=None):
        """Redraw one cell's figures. Pass sweeps to also redraw its traces."""
        if self.traces and sweeps is not None:
            self.plot_traces(cell_name, order, sweeps, results.vs_by_freq(cell_name))
        self.plot_itd_curves(cell_name, results)
        self.plt.pause(0.1)

    def plot_traces(self, cell_name, order, sweeps, vs=None, itds=None):
        from matplotlib.lines import Line2D
        import matplotlib.cm as cm

        for freq_idx, freq in enumerate(self.freqs) if self.freqs else enumerate([500]):
            if freq not in sweeps:
                continue
            trace_data = sweeps[freq].get("traces")
            if not trace_data:
                continue
            print(f"Plotting traces for {cell_name} at {freq} Hz: {len(trace_data)} ITD values")

            tax = self.trace_axes[f"{cell_name}_{int(order)}"][freq_idx, 0]
            
            title = f"{cell_name[:6]}_{order} {freq} Hz - "
            if vs is not None and freq in vs:
                title += f"VS={vs[freq]:.4f}"
            tax.set_title(title, fontsize=7)
            tax.set_xlim(self.plot_window)
            n_itds = len(trace_data)
            for idx, (itd, tr_list) in enumerate(trace_data.items()):
                if itds is not None and itd not in itds:
                    continue
                for tr in tr_list:
                    if self.only_aps and max(tr["voltage_axon"]) - tr["voltage_axon"][0] < 20:
                        continue
                    tax.plot(
                        tr["time_soma"],
                        np.array(tr["voltage_soma"]) - tr["voltage_soma"][0],
                        color=cm.gist_rainbow(idx / n_itds),
                        linewidth=0.5,
                        alpha=0.75,
                    )

            tax.set_ylabel("mV", fontsize=6)
            if freq_idx == len(self.freqs) - 1:
                tax.set_xlabel("Time (ms)", fontsize=6)
            keys = list(trace_data.keys())
            legend_itds = keys[:1] + keys[n_itds // 2 : n_itds // 2 + 1] + keys[-1:]
            handles, labels = zip(
                *[
                    (
                        Line2D([], [], color=cm.gist_rainbow(idx / n_itds), linewidth=0.5),
                        f"ITD: {itd} {self.stim.units}",
                    )
                    for idx, itd in enumerate(legend_itds)
                ]
            )
            tax.legend(handles, labels, loc="upper right")

        # self.trace_figs[cell_name].tight_layout()
        self.plt.pause(0.05)

    def plot_itd_curves(self, cell_name, results, freqs=None):
        freqs = self.freqs if freqs is None else freqs
        delta_vals = self.stim.delta_vals
        ax = self.master_axes[cell_name]
        ax.clear()
        ax.set_title(f"{cell_name}", fontsize=7)
        for freq in freqs:
            for order in self.orders:
                row_idx = results.row_lookup[cell_name][freq][order]
                spike_data = results.df.loc[row_idx, results.itd_columns].to_numpy(dtype=float)
                peak = spike_data.max()
                if peak == 0:
                    continue
                ax.plot(
                    delta_vals,
                    spike_data / peak,
                    color=self.freq_cmap(self.freq_norm(freq)),
                    alpha=1.0,
                    linewidth=2.0,
                    label=(
                        f'{freq} Hz (Max: {peak:.0f} @ {delta_vals[np.argmax(spike_data)]:.2f} '
                        f'{self.stim.units}) VS: {results.df.loc[row_idx, "vs"]:.2f}'
                    ),
                )
        ax.set_ylim(bottom=0, top=1.1)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_xlabel("Phase (cycles)" if self.stim.units == "cyc" else "ITD (ms)", fontsize=6)
        ax.set_ylabel("Norm. spike count", fontsize=6)
        handles, labels = ax.get_legend_handles_labels()
        unique = dict(zip(labels, handles))
        ax.legend(unique.values(), unique.keys(), fontsize=5, loc="upper right")
        self.master_figs[cell_name].tight_layout()
        self.plt.pause(0.1)

    def draw_initial(self, results):
        """Draw curves for whatever is already in the results table (e.g. a resumed CSV)."""
        for cell in results.df["cell"].unique():
            self.plot_itd_curves(cell, results, freqs=results.df["freq"].unique())

    # ── final figures ──
    def plot_master_traces(self, results, group_by="freq"):
        """Plot averaged soma/axon traces and save as a PDF, one row per frequency
        (group_by="freq") or per branch order (group_by="order")."""
        plt = self.plt
        configured = self.freqs if group_by == "freq" else self.orders
        observed = {
            freq if group_by == "freq" else order
            for cell_traces in results.master_traces.values()
            for order, by_freq in cell_traces.items()
            for freq in by_freq
        }
        rows = list(configured) + sorted(observed - set(configured))
        row_of = {key: i for i, key in enumerate(rows)}
        n = len(rows)
        fig, ax = plt.subplots(n, 2, figsize=(10, max(8, 2 * n)), sharex=True, sharey=True, squeeze=False)
        for cell_name, cell_traces in results.master_traces.items():
            for order, by_freq in cell_traces.items():
                for freq_key, by_delta in by_freq.items():
                    row = row_of[freq_key if group_by == "freq" else order]
                    time_grid = self.stim.master_trace_time(freq_key)
                    for delta_val, volts in by_delta.items():
                        label = f"Order: {order}, Freq: {freq_key}, Delta: {delta_val}"
                        ax[row, 0].plot(time_grid, volts["voltage_soma"], label=label)
                        ax[row, 1].plot(time_grid, volts["voltage_axon"], label=label)
        ax[0, 0].set_title("Soma Voltage")
        ax[0, 1].set_title("Axon Voltage")
        for row, key in enumerate(rows):
            for col in (0, 1):
                ax[row, col].set_xlim(self.plot_window)
                ax[row, col].set_xlabel("Time (ms)")
                ax[row, col].set_ylabel(f"{group_by.capitalize()} {key}\nVoltage (mV)")
                if ax[row, col].has_data():
                    ax[row, col].legend()
        suffix = "" if group_by == "freq" else "_by_order"
        fig.savefig(f"{self.plot_folder}/final_master_traces{suffix}.pdf")
        return fig

    def save_figures(self, include_traces=True):
        for name in self.cells:
            self.master_figs[name].savefig(f"{self.plot_folder}/final_results_{name}.pdf")
        if include_traces:
            for name in self.trace_figs:
                self.trace_figs[name].savefig(f"{self.plot_folder}/final_traces_{name}.pdf")

    def show(self):
        self.plt.show(block=True)
