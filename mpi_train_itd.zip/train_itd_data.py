"""Data handling for train_allcell: spike-time loading, results table, sweep
combination, trace averaging/saving and the final summary. No plotting here."""

import os
import pickle
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

MASTER_TRACE_SAMPLES = 100000


def calc_duration(cycles, freq, dur=None):
    return dur if dur is not None else (cycles / (freq / 1000))


@dataclass(frozen=True)
class StimParams:
    """Stimulus settings shared by the data and plotting code."""

    cycles: int
    duration: float | None
    stab_time: float
    delta_vals: list = field(default_factory=list)
    units: str = "ms"  # "cyc" for cycles (IPD) or "ms" for milliseconds (ITD)

    def calc_duration(self, freq):
        return calc_duration(self.cycles, freq, dur=self.duration)

    def delta_to_ms(self, delta, freq):
        """Convert delta value(s) to milliseconds for a given frequency."""
        if self.units == "ms":
            return delta
        return delta * 1000.0 / freq

    def delta_to_phase(self, delta, freq):
        """Convert delta value(s) to cycles (phase) for a given frequency."""
        if self.units == "cyc":
            return delta
        return delta * freq / 1000.0

    def master_trace_time(self, freq):
        return np.linspace(
            self.stab_time - 1, self.calc_duration(freq) + self.stab_time + 1, MASTER_TRACE_SAMPLES
        )


# ── Spike times ──────────────────────────────────────────────────────────────
def load_spike_times(freqs, stim, anf_num=None, synthetic=False):
    """Return {freq: [spike-time array (ms) per ANF fiber]}."""
    if synthetic:
        return {freq: [np.arange(0, stim.duration, 1 / freq) * 1000] for freq in freqs}
    raw = {}
    for freq in freqs:
        with open(f"spikes/spikes_{freq}hz.pkl", "rb") as f:
            raw[freq] = pickle.load(f)
    if anf_num is None:
        anf_num = len(raw[freqs[0]][0])
    return {
        freq: [
            np.array([s for s in fiber if s < stim.calc_duration(freq)]) * 1000
            for fiber in raw[freq][:anf_num]
        ]
        for freq in raw
    }


# ── Results table ────────────────────────────────────────────────────────────
def _blank_row(cell, freq, order, itd_columns):
    row = {"cell": cell, "freq": freq, "order": order, "vs": 0.0, "trials": 0}
    row.update({col: 0 for col in itd_columns})
    return row


def init_dataframe(cells, freqs, orders, phase_vals, results_file, overwrite=False):
    itd_columns = [str(v) for v in phase_vals]
    all_columns = ["cell", "freq", "order", "vs", "trials"] + itd_columns

    if os.path.exists(results_file) and not overwrite:
        df = pd.read_csv(results_file)
        for col in ["vs", "trials"] + itd_columns:
            if col not in df.columns:
                df[col] = 0
        # Initialize rows for any cell/freq combos missing from the CSV
        for cell in cells:
            for freq in freqs:
                for order in orders:
                    exists = (
                        (df["cell"] == cell) & (df["freq"] == freq) & (df["order"] == order)
                    ).any()
                    if not exists:
                        new_row = _blank_row(cell, freq, order, itd_columns)
                        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        df = df[all_columns]
    else:
        if len(freqs) == 0:
            freqs = [500]
        # An empty order list means full-arbor innervation, stored as order 99
        order_list = orders if len(orders) > 0 else [99]
        df = pd.DataFrame(
            [
                _blank_row(cell, freq, order, itd_columns)
                for cell in cells
                for freq in freqs
                for order in order_list
            ]
        )
    df.to_csv(results_file, index=False)

    row_lookup = {}
    for idx, row in df.iterrows():
        row_lookup.setdefault(row["cell"], {}).setdefault(row["freq"], {})[row["order"]] = idx
    return df, itd_columns, row_lookup


# ── Sweep combination (MPI gather) ───────────────────────────────────────────
def combine_sweep_parts(all_parts):
    """Merge the per-rank sweep dicts gathered by pc.py_gather into one."""
    combined = {}
    for part in all_parts:
        for freq, data in part.items():
            if freq not in combined:
                combined[freq] = {
                    "spike_counts": np.zeros_like(data["spike_counts"]),
                    "spike_times": {},
                    "traces": {},
                }
            combined[freq]["spike_counts"] += data["spike_counts"]
            for itd_key, times in data["spike_times"].items():
                if itd_key in combined[freq]["spike_times"]:
                    combined[freq]["spike_times"][itd_key] = np.concatenate(
                        [combined[freq]["spike_times"][itd_key], times]
                    )
                else:
                    combined[freq]["spike_times"][itd_key] = times
            for itd_key, tr in data.get("traces", {}).items():
                if itd_key in combined[freq]["traces"]:
                    combined[freq]["traces"][itd_key].extend(tr)
                else:
                    combined[freq]["traces"][itd_key] = tr
    return combined


# ── Traces ───────────────────────────────────────────────────────────────────
def save_trace(filename, data, stim, freq, samplerate=100000, which="soma"):
    """Resample one trace onto a fixed grid and pickle it. Returns True if written."""
    time_data = data.get(f"time_{which}", [])
    voltage_data = data.get(f"voltage_{which}", [])
    if len(time_data) == 0 or len(voltage_data) == 0:
        return False
    interp_tr = np.interp(
        np.linspace(99, stim.calc_duration(freq) + 99 + 2, samplerate),
        time_data,
        voltage_data,
    )
    with open(filename, "wb") as f:
        pickle.dump((interp_tr, samplerate // 1000), f)
    return True


def accumulate_master_trace(
    master_traces, cell_name, order, freq_key, delta_val, trace_list, stim, only_aps=False
):
    """Average a batch's soma/axon traces (resampled onto a common time axis) into
    master_traces[cell][order][freq][delta]."""
    delta_traces = master_traces[cell_name].setdefault(order, {}).setdefault(freq_key, {})
    if delta_val not in delta_traces:
        delta_traces[delta_val] = {
            "voltage_soma": np.zeros(MASTER_TRACE_SAMPLES),
            "voltage_axon": np.zeros(MASTER_TRACE_SAMPLES),
        }
    entry = delta_traces[delta_val]
    time_grid = stim.master_trace_time(freq_key)
    trace_count = 0
    for trace in trace_list:
        if only_aps:
            amplitude = max(trace["voltage_axon"]) - trace["voltage_axon"][0]
            if amplitude < 20:
                print(
                    f"Skipping trace for cell {cell_name}, order {order}, freq {freq_key}, delta {delta_val} "
                    f"due to insufficient AP amplitude {amplitude}."
                )
                continue
        trace_count += 1
        for time_key, voltage_key in (("time_soma", "voltage_soma"), ("time_axon", "voltage_axon")):
            interp_tr = np.interp(time_grid, trace.get(time_key, []), trace.get(voltage_key, []))
            entry[voltage_key] += interp_tr - interp_tr[0]
    entry["voltage_soma"] /= trace_count
    entry["voltage_axon"] /= trace_count


# ── Collector ────────────────────────────────────────────────────────────────
class ResultsCollector:
    """Accumulates sweep results, spike times and averaged traces on the master rank."""

    def __init__(
        self,
        cells,
        freqs,
        orders,
        stim,
        results_file,
        overwrite=False,
        spike_times_file=None,
        trace_folder=None,
        only_aps=False,
    ):
        self.stim = stim
        self.results_file = results_file
        self.spike_times_file = spike_times_file
        self.trace_folder = trace_folder
        self.only_aps = only_aps
        self.df, self.itd_columns, self.row_lookup = init_dataframe(
            cells, freqs, orders, stim.delta_vals, results_file, overwrite
        )
        self.trial_count = 0
        self.spike_times_rows = []
        self.master_traces = {cell: {} for cell in cells}

    def add_batch(self, cell_name, order, sweeps):
        """Fold one finished batch (spike counts + spike times) into the results."""
        order = int(order)
        for freq_key, sweep in sweeps.items():
            self._accumulate_counts(cell_name, freq_key, order, sweep)
            self.trial_count += len(self.stim.delta_vals)
            self._collect_spike_times(cell_name, freq_key, order, sweep)

    def add_traces(self, cell_name, order, sweeps):
        """Average a batch's traces into master_traces and save the latest raw trace per freq."""
        order = int(order)
        for freq_key, sweep in sweeps.items():
            for delta_val, trace_list in sweep.get("traces", {}).items():
                accumulate_master_trace(
                    self.master_traces, cell_name, order, freq_key, delta_val, trace_list,
                    self.stim, only_aps=self.only_aps,
                )
            self._save_latest_trace(cell_name, order, freq_key, sweep)

    def vs_by_freq(self, cell_name):
        return (
            self.df.loc[self.df["cell"] == cell_name, ["freq", "vs"]]
            .set_index("freq")
            .to_dict()["vs"]
        )

    def save_results(self):
        self.df.to_csv(self.results_file, index=False, mode="w")

    def save_spike_times(self):
        if not self.spike_times_rows:
            return
        st_df = pd.DataFrame(self.spike_times_rows)
        st_df.to_csv(self.spike_times_file, index=False)
        print(f"Spike times saved to {self.spike_times_file} ({len(st_df)} spikes)")

    def print_firing_rates(self, cells, freqs, trials):
        for cell_name in cells:
            print(f"Firing Rate for Cell: {cell_name}:")
            for freq in freqs:
                elapsed = self.stim.duration if self.stim.duration else self.stim.cycles * (1 / freq)
                rate = (
                    self.df.loc[
                        (self.df["freq"] == freq) & (self.df["cell"] == cell_name), self.itd_columns
                    ].sum(axis=1).max()
                    / (elapsed * trials)
                    / len(self.stim.delta_vals)
                )
                print(f"  Freq: {freq} Hz: {rate*1000:.4f} spikes/s")

    # ── internals ──
    def _accumulate_counts(self, cell_name, freq_key, order, sweep):
        row_idx = self.row_lookup[cell_name][freq_key][order]
        for itd_idx, itd_val in enumerate(self.stim.delta_vals):
            col = str(itd_val)
            self.df.at[row_idx, col] = self.df.at[row_idx, col] + sweep["spike_counts"][itd_idx]
        self.df.at[row_idx, "trials"] = self.df.at[row_idx, "trials"] + 1

    def _collect_spike_times(self, cell_name, freq_key, order, sweep):
        for delta_val, st in sweep.get("spike_times", {}).items():
            if st is None or len(st) == 0:
                continue
            self.spike_times_rows.extend(
                {
                    "cell": cell_name,
                    "order": order,
                    "freq": freq_key,
                    "delta": delta_val,
                    "spike_time_ms": t,
                }
                for t in st
            )

    def _save_latest_trace(self, cell_name, order, freq_key, sweep):
        if self.trace_folder is None:
            return
        filename = f"{self.trace_folder}/{cell_name}_{order}_{freq_key}_traces.pkl"
        for tr_list in reversed(list(sweep.get("traces", {}).values())):
            for tr in reversed(tr_list):
                if save_trace(filename, tr, self.stim, freq_key):
                    return
