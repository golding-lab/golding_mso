import os
import golding_mso as gmso
import pandas as pd
from neuron import h
import numpy as np
import gc
import time
import random
import contextlib
import sys

from train_itd_data import (
    StimParams,
    ResultsCollector,
    combine_sweep_parts,
    load_spike_times,
)
from train_itd_plots import Plotter

gmso.console_handler.setLevel("ERROR")
gmso.rotate_handler.setLevel("ERROR")
start_time = time.time()

# ── Configuration ────────────────────────────────────────────────────────────
SIM = True
PLOT = False  # Whether to generate plots
TRACES = False  # Whether to generate traces
OVERWRITE = True  # Whether to overwrite existing results files
ONE_CELL_AT_A_TIME = True  # If False, ranks will split freq/trial combos across all cells. If True, each cell is done sequentially by a subset of ranks (prioritizes maintaining cell instances across multiple trials).
NODE_ID = random.randint(0, 1000)
RESULTS_FILE = f"train_itd_results_{time.strftime('%m%d')}_{NODE_ID:04d}.csv"
SPIKE_TIMES_FILE = "train_spike_times.csv"
TRACE_FOLDER = "traces"
PLOT_FILE_FOLDER = "plots"
RECORD_SPIKE_TIMES = True  # Whether to record spike times
ONLY_APS = False
SYNTHETIC_SPIKES = False  # Whether to override existing spike times with synthetic ones

CYCLES = 0
DURATION = 200  # If None, duration will be calculated from cycles and frequency.
DELTA_VALS = np.arange(-0.75, 0.751, 0.01)  # ITD/IPD values to test
UNITS = "ms"  # "cyc" for cycles (IPD) or "ms" for milliseconds (ITD)
STAB_TIME = 200
STIM = StimParams(
    cycles=CYCLES,
    duration=DURATION,
    stab_time=STAB_TIME,
    delta_vals=DELTA_VALS,
    units=UNITS,
)
TRIALS = 200

FREQS = [250, 500, 1000, 2000]  # List of stimulus frequencies to test
ORDERS = []  # List of branch orders to test (primary branches = 0, primary+secondary = 1, etc.). [] = orders not varied
ORDER_FREQ = 500  # Frequency used when the testing branch order innervation.

ANF_NUM = 6  # Number of ANF spike time sets used per trial
EXC_GMAX = 0.18  # Total maximum conductance for all excitatory synapses
INH_GMAX = 0.18  # Total maximum conductance for all inhibitory synapses
EXC_VESICLE_POOL_SIZE = 40  # Size of the vesicle pool for excitatory synapses
INH_VESICLE_POOL_SIZE = 40  # Size of the vesicle pool for inhibitory synapses

CELLS = {name: morph for name, morph in list(gmso.morphologies.items())}

START_TIME = time.time()
if not os.path.exists(PLOT_FILE_FOLDER) and PLOT:
    os.makedirs(PLOT_FILE_FOLDER, exist_ok=True)
if not os.path.exists(TRACE_FOLDER) and TRACES:
    os.makedirs(TRACE_FOLDER, exist_ok=True)

PLOT_WINDOW = np.array([7.5, 57.5]) + STAB_TIME


# ── Simulation ───────────────────────────────────────────────────────────────
class _SuppressOutput:
    def write(self, x):
        pass


def create_cell(key, path):
    cell = gmso.Cell(path, compartment_size=15)
    cell.attach_axon()
    cell.__setattr__("pc_id", pc.id())
    return cell


def itd_batch_task_split(cell_name, trials=1, seed=None, order=0, freqs=FREQS):
    """Run ITD sweeps for one cell. Ranks in the subworld split freq/trial pairs."""
    task_start_time = time.time()
    random.seed(seed)

    with contextlib.redirect_stdout(_SuppressOutput()):
        cell = create_cell(cell_name, gmso.morphologies[cell_name])
        if pc.id() == 0:
            print(
                f"Vrest: {cell.resting_potential}, Tau: {cell.time_constant}, Rin: {cell.input_resistance}"
            )
    cell.stabilization_time = STAB_TIME
    secs_to_use = [[], []]
    for listind, seclist in enumerate(
        [cell.lateral_nofilopodia, cell.medial_nofilopodia]
    ):
        for sec in seclist:
            parents = gmso.cell_calc.get_parent_sections(sec)
            if len(parents) <= order + 1:
                secs_to_use[listind].append(sec)
    if pc.id() != 0:
        my_tasks = [
            (delta, freq, trial)
            for delta in DELTA_VALS
            for freq in freqs
            for trial in range(int(trials))
        ][pc.id() - 1 :: pc.nhost() - 1]
    else:
        my_tasks = []
    if len(secs_to_use[0]) == 0 or len(secs_to_use[1]) == 0:
        print(
            f"Host {pc.id()} - WARNING: No sections found for cell {cell_name} at order {order}. Skipping ITD setup."
        )
        return None
    itd = gmso.sims.ITDTest(
        cell,
        secs_to_use[0],
        secs_to_use[1],
        axonspeed=1,
        record_axon=True,
        threshold=25,
        exc_gmax=EXC_GMAX,
        fibered=True,
        inhibition=True,
        inh_gmax=INH_GMAX,
        itd_vals=STIM.delta_to_ms(DELTA_VALS, min(freqs)),
        seed=int(seed),
        traces=TRACES,
        exc_rzero=EXC_VESICLE_POOL_SIZE,
        inh_rzero=INH_VESICLE_POOL_SIZE,
    )
    total_tasks = len(DELTA_VALS) * len(freqs) * int(trials)

    my_sweeps = {
        freq: {
            "spike_counts": np.zeros(len(DELTA_VALS)),
            "spike_times": {},
            "traces": {},
        }
        for freq in freqs
    }
    num_completed = 0
    for idx, (delta, freq, trial) in enumerate(my_tasks):
        duration_val = STIM.calc_duration(freq)
        itd.set_spike_trains(
            random.choices(SPIKE_TIMES[freq], k=ANF_NUM), which="exc", method="random"
        )
        itd.set_spike_trains(
            random.choices(SPIKE_TIMES[freq], k=ANF_NUM), which="inh", method="random"
        )
        itd.seed = int(seed * (trial + 1) * freq)
        itd_result = itd.run_at_itd(
            STIM.delta_to_ms(delta, freq), duration=duration_val
        )
        my_sweeps[freq]["spike_counts"][list(DELTA_VALS).index(delta)] += itd_result[
            "spike_count"
        ]
        if my_sweeps[freq]["spike_times"].get(delta) is None:
            my_sweeps[freq]["spike_times"][delta] = itd_result["spike_times"]
        else:
            my_sweeps[freq]["spike_times"][delta] = np.concatenate(
                [my_sweeps[freq]["spike_times"][delta], itd_result["spike_times"]]
            )
        if my_sweeps[freq]["traces"].get(delta) is None and TRACES:
            my_sweeps[freq]["traces"][delta] = [itd_result["traces"]]
        elif TRACES:
            my_sweeps[freq]["traces"][delta].append(itd_result["traces"])
        num_completed += 1
        if pc.id() == 1:
            if (len(my_tasks)) >= 100 and num_completed % (len(my_tasks) // 100) == 0:
                elapsed_time = (time.time() - task_start_time) / 60
                estimated_total_time = (
                    (elapsed_time / num_completed) * len(my_tasks) - elapsed_time
                    if num_completed > 0
                    else 0
                )
                speed = (
                    ((time.time() - task_start_time) / num_completed)
                    if len(my_tasks) > 0
                    else 0
                )

                print(
                    f"\rHOST {pc.id():<3} [{num_completed:>4}/{len(my_tasks)} | {elapsed_time:.2f}m | {speed:.2f}s/task | ETA {estimated_total_time:.2f}m] [{'#'*(num_completed//(len(my_tasks)//100))}{'-'*((len(my_tasks) - num_completed)//(len(my_tasks)//100))}]",
                    end="",
                )
                sys.stdout.flush()
            elif (len(my_tasks)) < 100:
                elapsed_time = (time.time() - task_start_time) / 60
                estimated_total_time = (
                    (elapsed_time / num_completed) * len(my_tasks) - elapsed_time
                    if num_completed > 0
                    else 0
                )
                speed = (
                    ((time.time() - task_start_time) / num_completed)
                    if len(my_tasks) > 0
                    else 0
                )

                print(
                    f"\rHOST {pc.id():<3} [{num_completed:>4}/{len(my_tasks)} | {(time.time() - START_TIME)/60:.2f}m | {speed:.2f}s/task | ETA {estimated_total_time:.2f}m] [{'#'*(num_completed)}{'-'*((len(my_tasks) - num_completed))}]",
                    end="",
                )
                sys.stdout.flush()
    elapsed_time = (time.time() - task_start_time) / 60
    speed = (
        ((time.time() - task_start_time) / len(my_tasks)) if len(my_tasks) > 0 else 0
    )

    if pc.id() == 1:
        print(
            f"\r[{total_tasks}/{total_tasks} | {(time.time() - START_TIME)/60:.2f}m | {speed:.2f}s/task]",
            end="",
        )
        sys.stdout.flush()
    all_parts = pc.py_gather(my_sweeps, 0)
    try:
        del cell, itd
    except:
        pass
    gc.collect()

    if pc.id() == 0:
        combined = combine_sweep_parts(all_parts)
        return cell_name, order, combined, pc.id_world()
    return None


def submit_tasks(seed_base):
    """Queue one simulation task per cell (and per order when ORDERS is set)."""
    cond_df = pd.read_csv("inh_mag_test.csv")
    for ind, cell in enumerate(CELLS.keys()):
        if len(ORDERS) > 0:
            for order in ORDERS:
                seed = int((ind + 1) * seed_base) if seed_base is not None else None
                print(
                    f"Submitting task for cell={cell}, order={order}, seed={seed}, {type(seed)}"
                )
                pc.submit(itd_batch_task_split, cell, TRIALS, seed, order, [ORDER_FREQ])
        else:
            seed = int((ind + 2) * seed_base) if seed_base is not None else None
            pc.submit(itd_batch_task_split, cell, TRIALS, seed, 99, FREQS)


def collect_results(results, plotter=None):
    """Consume finished batches from the workers, accumulating data and refreshing plots."""
    while pc.working():
        result = pc.pyret()
        if result is None:
            continue
        cell_name, order, sweeps, world_id = result

        results.add_batch(cell_name, order, sweeps)
        for key, value in sweeps.items():
            print(f"{key}: {value['spike_counts']}")

        if plotter is not None:
            if TRACES:
                results.add_traces(cell_name, order, sweeps)
                plotter.update(cell_name, order, results, sweeps)
            else:
                plotter.update(cell_name, order, results)
        results.save_results()


# ── MPI bootstrap ───────────────────────────────────────────────────────────
h.nrnmpi_init()
pc = h.ParallelContext()
SUBWORLD_SIZE = max(1, pc.nhost_world() // len(CELLS))
SUBWORLD_SIZE = pc.nhost_world() if ONE_CELL_AT_A_TIME else SUBWORLD_SIZE

pc.subworlds(SUBWORLD_SIZE)

if pc.id_world() == 0:
    SEED = random.randint(0, 10000)
    # SEED = None
    print(f'Time: {time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())}')
    print(f"ID: {NODE_ID}")
    print(
        f"Simulation started with SEED={SEED}, PLOT={PLOT}, SIM={SIM}, TRACES={TRACES}"
    )
    print(
        f"Subworlds: {pc.nhost_bbs()} subworlds of {SUBWORLD_SIZE} ranks "
        f"({pc.nhost_world()} total MPI ranks)"
    )
    if not len(DELTA_VALS) < 2:
        print(
            f"Cells: {list(CELLS.keys())}\nFrequencies: {FREQS}\nDuration: {str(DURATION)}\nDeltas ({UNITS}): ({DELTA_VALS[0]:.2f} > +{DELTA_VALS[1]-DELTA_VALS[0]:.2f} > {DELTA_VALS[-1]:.2f})\nTrials per frequency: {TRIALS}"
        )

    sys.stdout.flush()

SPIKE_TIMES = load_spike_times(
    FREQS if FREQS else [500], STIM, anf_num=ANF_NUM, synthetic=SYNTHETIC_SPIKES
)

# ── Main (master rank only) ─────────────────────────────────────────────────
pc.runworker()

results = ResultsCollector(
    CELLS,
    FREQS,
    ORDERS,
    STIM,
    RESULTS_FILE,
    overwrite=OVERWRITE,
    spike_times_file=SPIKE_TIMES_FILE,
    trace_folder=TRACE_FOLDER if TRACES else None,
    only_aps=ONLY_APS,
)

plotter = None
if PLOT and pc.id_world() == 0:
    plotter = Plotter(
        CELLS,
        FREQS,
        ORDERS,
        STIM,
        PLOT_WINDOW,
        PLOT_FILE_FOLDER,
        traces=TRACES,
        only_aps=ONLY_APS,
    )
    plotter.draw_initial(results)

if SIM:
    submit_tasks(SEED)
    collect_results(results, plotter)

if plotter is not None and TRACES:
    plotter.plot_master_traces(results, group_by="freq")
    plotter.plot_master_traces(results, group_by="order")

# ── Final summary ────────────────────────────────────────────────────────────
results.print_firing_rates(CELLS, FREQS, TRIALS)
results.save_results()
if SIM and RECORD_SPIKE_TIMES:
    results.save_spike_times()
if plotter is not None:
    plotter.save_figures(include_traces=SIM and TRACES)
    plotter.show()
pc.done()
